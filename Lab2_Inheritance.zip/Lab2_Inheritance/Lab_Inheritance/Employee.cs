﻿// Employee.cs
public abstract class Employee
{
    public string Id { get; }
    public string Name { get; }
    public string Address { get; }
    public string Phone { get; }
    public long Sin { get; }
    public string Dob { get; }
    public string Dept { get; }

    protected Employee(string id, string name, string address, string phone, long sin, string dob, string dept)
    {
        Id = id;
        Name = name;
        Address = address;
        Phone = phone;
        Sin = sin;
        Dob = dob;
        Dept = dept;
    }

    public abstract double GetWeeklyPay();
}
