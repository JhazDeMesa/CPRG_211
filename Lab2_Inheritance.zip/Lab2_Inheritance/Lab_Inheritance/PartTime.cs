﻿// PartTime.cs
public class PartTime : Wages // Inherits from Wages because they have the same attributes
{
    public PartTime(string id, string name, string address, string phone, long sin, string dob, string dept, double hourlyRate, double hoursWorked)
        : base(id, name, address, phone, sin, dob, dept, hourlyRate, hoursWorked)
    {
    }

    public override double GetWeeklyPay()
    {
        // PartTime employees do not get overtime compensation
        return HourlyRate * HoursWorked;
    }
}
