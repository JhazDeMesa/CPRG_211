﻿// Program.cs
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

public class Program
{
    public static void Main()
    {
        string filePath = @"C:\CPRG211\Lab2_Inheritance\Res\employees.txt";
        List<Employee> employees = LoadEmployees(filePath);

        Console.WriteLine("Average weekly pay for all employees: " + CalculateAverageWeeklyPay(employees).ToString("C", CultureInfo.CurrentCulture));
        var highestPayWageEmployee = CalculateHighestWeeklyPayForWageEmployees(employees);
        Console.WriteLine($"Highest weekly pay for wage employees: {highestPayWageEmployee.Name} - {highestPayWageEmployee.GetWeeklyPay().ToString("C", CultureInfo.CurrentCulture)}");
        var lowestSalarySalariedEmployee = CalculateLowestSalaryForSalariedEmployees(employees);
        Console.WriteLine($"Lowest salary for salaried employees: {lowestSalarySalariedEmployee.Name} - {lowestSalarySalariedEmployee.GetWeeklyPay().ToString("C", CultureInfo.CurrentCulture)}");
        CalculateAndPrintEmployeeCategoryPercentages(employees);
    }

    private static List<Employee> LoadEmployees(string filePath)
    {
        var employees = new List<Employee>();

        var lines = File.ReadAllLines(filePath);
        foreach (var line in lines)
        {
            var data = line.Split(':');
            if (data.Length < 8)
            {
                Console.WriteLine("Skipping line due to insufficient data: " + line);
                continue; // Skip this line to guarantees that an attempt to parse insufficient data is not undertaken
            }

            var id = data[0].Trim();
            var name = data[1].Trim();
            var address = data[2].Trim();
            var phone = data[3].Trim();
            var sin = long.Parse(data[4].Trim());
            var dob = data[5].Trim();
            var dept = data[6].Trim();
            var payRate = double.Parse(data[7].Trim());

            Employee employee = null;

            if (id.StartsWith("0") || id.StartsWith("1") || id.StartsWith("2") || id.StartsWith("3") || id.StartsWith("4"))
            {
                employee = new Salaried(id, name, address, phone, sin, dob, dept, payRate);
            }
            else if (id.StartsWith("5") || id.StartsWith("6") || id.StartsWith("7"))
            {
                if (data.Length < 9)
                {
                    Console.WriteLine("Skipping line due to missing hours data for wage employee: " + line);
                    continue;
                }
                var hours = double.Parse(data[8].Trim());
                employee = new Wages(id, name, address, phone, sin, dob, dept, payRate, hours);
            }
            else if (id.StartsWith("8") || id.StartsWith("9"))
            {
                if (data.Length < 9)
                {
                    Console.WriteLine("Skipping line due to missing hours data for part-time employee: " + line);
                    continue;
                }
                var hours = double.Parse(data[8].Trim());
                employee = new PartTime(id, name, address, phone, sin, dob, dept, payRate, hours);
            }

            if (employee != null)
            {
                employees.Add(employee);
            }
        }

        return employees;
    }

    private static double CalculateAverageWeeklyPay(List<Employee> employees)
    {
        return employees.Average(emp => emp.GetWeeklyPay());
    }

    private static Wages CalculateHighestWeeklyPayForWageEmployees(List<Employee> employees)
    {
        return employees
            .OfType<Wages>()
            .OrderByDescending(emp => emp.GetWeeklyPay())
            .First();
    }

    private static Salaried CalculateLowestSalaryForSalariedEmployees(List<Employee> employees)
    {
        return employees
            .OfType<Salaried>()
            .OrderBy(emp => emp.GetWeeklyPay())
            .First();
    }

    private static void CalculateAndPrintEmployeeCategoryPercentages(List<Employee> employees)
    {
        int totalEmployees = employees.Count;
        int salariedCount = employees.OfType<Salaried>().Count();
        int wagesCount = employees.OfType<Wages>().Count();
        int partTimeCount = employees.OfType<PartTime>().Count();

        Console.WriteLine($"Percentage of Salaried Employees: {(double)salariedCount / totalEmployees * 100:F2}%");
        Console.WriteLine($"Percentage of Wage Employees: {(double)wagesCount / totalEmployees * 100:F2}%");
        Console.WriteLine($"Percentage of Part-Time Employees: {(double)partTimeCount / totalEmployees * 100:F2}%");
    }
}
