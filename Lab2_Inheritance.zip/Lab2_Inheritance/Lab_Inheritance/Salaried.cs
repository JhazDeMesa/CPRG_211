﻿// Salaried.cs
public class Salaried : Employee
{
    public double Salary { get; }

    public Salaried(string id, string name, string address, string phone, long sin, string dob, string dept, double salary)
        : base(id, name, address, phone, sin, dob, dept)
    {
        Salary = salary;
    }

    public override double GetWeeklyPay()
    {
        return Salary;
    }
}
