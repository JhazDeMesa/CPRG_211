﻿// Wages.cs
public class Wages : Employee
{
    public double HourlyRate { get; }
    public double HoursWorked { get; }

    public Wages(string id, string name, string address, string phone, long sin, string dob, string dept, double hourlyRate, double hoursWorked)
        : base(id, name, address, phone, sin, dob, dept)
    {
        HourlyRate = hourlyRate;
        HoursWorked = hoursWorked;
    }

    public override double GetWeeklyPay()
    {
        double overtimeHours = HoursWorked > 40 ? HoursWorked - 40 : 0;
        double overtimePay = overtimeHours * HourlyRate * 1.5;
        double regularPay = (HoursWorked - overtimeHours) * HourlyRate;
        return regularPay + overtimePay;
    }
}
